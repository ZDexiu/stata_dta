gdsge_codegen('safe_assets');

IterRslt = iter_safe_assets;