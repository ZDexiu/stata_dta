% This file is a part of GDSGE. License is Apache License, Version 2.0: http://github.com/gdsge/gdsge/LICENSE
function [IterRslt,IterFlag] = iter_rbc(GDSGE_OPTIONS)
%% Add path
if ispc
    BLAS_FILE = 'essential_blas.dll';
    PATH_DELIMITER = ';';
    
    GDSGE_TOOLBOX_ROOT = fileparts(which(BLAS_FILE));
    if ~any(strcmp(strsplit(getenv('PATH'),PATH_DELIMITER),GDSGE_TOOLBOX_ROOT))
        setenv('PATH',[getenv('PATH'),PATH_DELIMITER,GDSGE_TOOLBOX_ROOT]);
    end
    
    clear BLAS_FILE PATH_DELIMITER GDSGE_TOOLBOX_ROOT
elseif ismac
    if exist('./essential_blas.dylib','file') == 0
        copyfile(which('essential_blas.dylib'),'./');
    end
end

%% Iter code starts here
TolEq = 1e-6;
TolSol = 1e-8;
TolFun = 1e-8;
PrintFreq = 10;
NoPrint = 0;
SaveFreq = 10;
NoSave = 0;
SimuPrintFreq = 1000;
SimuSaveFreq = inf;
MaxIter = inf;
MaxMinorIter = inf;
num_samples = 1;
num_periods = 1000;
SolMaxIter = 200;

% task constants
MEX_TASK_INIT = 0;
MEX_TASK_INF_HORIZON = 1;

% Solver
UseBroyden = 0;
FiniteDiffDelta = 1e-6;

% DEBUG flag
GDSGE_DEBUG_EVAL_ONLY = 0;
GDSGE_USE_BROYDEN = 1;
GDSGE_USE_BROYDEN_NOW = 0;
INTERP_ORDER = 4;
EXTRAP_ORDER = 2;
OutputInterpOrder = 2;
USE_SPLINE = 1;
GDSGE_USE_OLD_VEC = 0;
USE_ASG = 0;
USE_PCHIP = 0;
USE_SPARSE_JACOBIAN = 0;
SIMU_INTERP = 0;
SIMU_RESOLVE = 1;
SimuSeed = 0823;
AsgMinLevel = 4;
AsgMaxLevel = 10;
AsgThreshold = 1e-2;
AsgOutputMaxLevel = 10;
AsgOutputThreshold = 1e-2;
IterSaveAll = 0;
SkipModelInit = 0;
GDSGE_EMPTY = [];
GDSGE_ASG_FIX_GRID = 0;
UseModelId = 0;
MinBatchSol = 1;
UseAdaptiveBound = 1;
UseAdaptiveBoundInSol = 0;
EnforceSimuStateInbound = 1;
REMOVE_NULL_STATEMENTS = 0;
REUSE_WARMUP_SOL = 1;
INTERP_WARMUP_SOL = 1;
CONSTRUCT_OUTPUT = 1;
shock_num = 1;
shock_trans = 1;
NumThreads = feature('numcores');
GDSGE_dummy_state = zeros(1,NumThreads*4);
GDSGE_dummy_shock = 0;
USE_FINITE_DIFF = 0;
DEFAULT_PARAMETERS_END_HERE = true;
beta  = 0.99;
sigma = 2.0;
alpha = 0.36;
delta = 0.025;
shock_num = 2;
z_low = 0.99;
z_high = 1.01;
Pr_ll = 0.9;
Pr_hh  = 0.9;
z = [z_low,z_high];
shock_trans = [;
Pr_ll, 1-Pr_ll;
1-Pr_hh, Pr_hh;
];
Kss  = (alpha/(1/beta - 1 + delta))^(1/(1-alpha));
KPts = 101;
KMin = Kss*0.9;
KMax = Kss*1.1;
K    = linspace(KMin,KMax,KPts);


if nargin>=1
    if isfield(GDSGE_OPTIONS,'WarmUp')
        if isfield(GDSGE_OPTIONS.WarmUp,'var_tensor')
            v2struct(GDSGE_OPTIONS.WarmUp.var_tensor);
        end
    end
    v2struct(GDSGE_OPTIONS)
end
  
assert(exist('shock_num','var')==1);
assert(length(z)==2);
assert(size(shock_trans,1)==2);
assert(size(shock_trans,2)==2);


%% Solve the last period problem


%% Solve the infinite horizon problem
[GDSGE_TENSOR_shockIdx,GDSGE_TENSOR_K]=ndgrid(1:shock_num,K);
GDSGE_TENSOR_z=ndgrid(z,K);
GDSGE_NPROB=numel(GDSGE_TENSOR_shockIdx);




GDSGE_SIZE = size(GDSGE_TENSOR_shockIdx);
GDSGE_SIZE_STATE = num2cell(GDSGE_SIZE(2:end));

GDSGE_LB = zeros(2,GDSGE_NPROB);
GDSGE_UB = 1e3*ones(2,GDSGE_NPROB);
GDSGE_LB(1:1,:)=0;
GDSGE_UB(1:1,:)=GDSGE_TENSOR_z(:)'.*GDSGE_TENSOR_K(:)'.^alpha+(1-delta)*GDSGE_TENSOR_K(:)';
GDSGE_LB(2:2,:)=0;
GDSGE_UB(2:2,:)=GDSGE_TENSOR_z(:)'.*GDSGE_TENSOR_K(:)'.^alpha+(1-delta)*GDSGE_TENSOR_K(:)';


GDSGE_EQVAL = 1e20*ones(2,GDSGE_NPROB);
GDSGE_F = 1e20*ones(1,GDSGE_NPROB);
GDSGE_SOL = zeros(2,GDSGE_NPROB);
GDSGE_X0 = rand(size(GDSGE_SOL)) .* (GDSGE_UB-GDSGE_LB) + GDSGE_LB;
GDSGE_SOL(:) = GDSGE_X0;
GDSGE_AUX = zeros(1,GDSGE_NPROB);
GDSGE_SKIP = zeros(1,GDSGE_NPROB);
GDSGE_DATA = zeros(13,GDSGE_NPROB);

if ~( nargin>=1 && isfield(GDSGE_OPTIONS,'WarmUp') && isfield(GDSGE_OPTIONS.WarmUp,'var_interp') )
    c_interp=zeros(GDSGE_SIZE);
c_interp(:)=GDSGE_TENSOR_z(:)'.*GDSGE_TENSOR_K(:)'.^alpha+(1-delta)*GDSGE_TENSOR_K(:)';

    
    GDSGE_INTERP_ORDER = INTERP_ORDER*ones(1,length(GDSGE_SIZE_STATE));
GDSGE_EXTRAP_ORDER = EXTRAP_ORDER*ones(1,length(GDSGE_SIZE_STATE));

GDSGE_PP_c_interp=struct('form','pp','breaks',{{K}},'Values',reshape(c_interp,[],GDSGE_SIZE_STATE{:}),'coefs',[],'order',GDSGE_INTERP_ORDER,'Method',[],'ExtrapolationOrder',GDSGE_EXTRAP_ORDER,'thread',NumThreads,'orient','curvefit');
GDSGE_PP_c_interp=myppual(myppual(GDSGE_PP_c_interp));



% Construct the vectorized spline
if ~GDSGE_USE_OLD_VEC
    GDSGE_SPLINE_VEC = convert_to_interp_eval_array({GDSGE_PP_c_interp});
end

end

GDSGE_Metric = 1;
GDSGE_Iter = 0;
IS_WARMUP_LOOP = 0;

if nargin>=1 && isfield(GDSGE_OPTIONS,'WarmUp')
    if isfield(GDSGE_OPTIONS.WarmUp,'var_interp')
        v2struct(GDSGE_OPTIONS.WarmUp.var_interp);
        GDSGE_TEMP = v2struct(K,GDSGE_SIZE_STATE);
        if isfield(GDSGE_OPTIONS.WarmUp,'GDSGE_PROB')
        GDSGE_SIZE_STATE = num2cell(GDSGE_OPTIONS.WarmUp.GDSGE_PROB.GDSGE_SIZE(2:end));
        end
        if isfield(GDSGE_OPTIONS.WarmUp,'var_state')
        v2struct(GDSGE_OPTIONS.WarmUp.var_state);    
        end
        GDSGE_INTERP_ORDER = INTERP_ORDER*ones(1,length(GDSGE_SIZE_STATE));
GDSGE_EXTRAP_ORDER = EXTRAP_ORDER*ones(1,length(GDSGE_SIZE_STATE));

GDSGE_PP_c_interp=struct('form','pp','breaks',{{K}},'Values',reshape(c_interp,[],GDSGE_SIZE_STATE{:}),'coefs',[],'order',GDSGE_INTERP_ORDER,'Method',[],'ExtrapolationOrder',GDSGE_EXTRAP_ORDER,'thread',NumThreads,'orient','curvefit');
GDSGE_PP_c_interp=myppual(myppual(GDSGE_PP_c_interp));



% Construct the vectorized spline
if ~GDSGE_USE_OLD_VEC
    GDSGE_SPLINE_VEC = convert_to_interp_eval_array({GDSGE_PP_c_interp});
end

        v2struct(GDSGE_TEMP);
        IS_WARMUP_LOOP = 1;
    end
    if isfield(GDSGE_OPTIONS.WarmUp,'Iter')
        GDSGE_Iter = GDSGE_OPTIONS.WarmUp.Iter;
    end
    if isfield(GDSGE_OPTIONS.WarmUp,'GDSGE_SOL')
        if ~isequal(size(GDSGE_OPTIONS.WarmUp.GDSGE_SOL,1),size(GDSGE_SOL,1))
            error('Wrong size of GDSGE_SOL in WarmUp');
        end
        GDSGE_SOL = GDSGE_OPTIONS.WarmUp.GDSGE_SOL;
    end
    if REUSE_WARMUP_SOL==1 && isfield(GDSGE_OPTIONS.WarmUp,'GDSGE_PROB') && size(GDSGE_OPTIONS.WarmUp.GDSGE_PROB.GDSGE_SOL,1)==size(GDSGE_SOL,1)
        if INTERP_WARMUP_SOL==1 && shock_num>=4
        % Interpolate SOL, LB, and UB
        GDSGE_TEMP = v2struct(K,GDSGE_SIZE_STATE);
        GDSGE_SIZE_STATE = num2cell(GDSGE_OPTIONS.WarmUp.GDSGE_PROB.GDSGE_SIZE);
        v2struct(GDSGE_OPTIONS.WarmUp.var_state);
        GDSGE_SOL_interp=struct('form','MKL','breaks',{{[1:shock_num],K}},'Values',reshape(GDSGE_OPTIONS.WarmUp.GDSGE_PROB.GDSGE_SOL,[],GDSGE_SIZE_STATE{:}),'coefs',[],'order',[2*ones(1,length(GDSGE_SIZE_STATE))],'Method',[],'ExtrapolationOrder',[2*ones(1,length(GDSGE_SIZE_STATE))],'thread',NumThreads,'orient','curvefit');
        GDSGE_SOL_interp=myppual(GDSGE_SOL_interp);
        GDSGE_LB_interp=struct('form','MKL','breaks',{{[1:shock_num],K}},'Values',reshape(GDSGE_OPTIONS.WarmUp.GDSGE_PROB.GDSGE_LB,[],GDSGE_SIZE_STATE{:}),'coefs',[],'order',[2*ones(1,length(GDSGE_SIZE_STATE))],'Method',[],'ExtrapolationOrder',[2*ones(1,length(GDSGE_SIZE_STATE))],'thread',NumThreads,'orient','curvefit');
        GDSGE_LB_interp=myppual(GDSGE_LB_interp);
        GDSGE_UB_interp=struct('form','MKL','breaks',{{[1:shock_num],K}},'Values',reshape(GDSGE_OPTIONS.WarmUp.GDSGE_PROB.GDSGE_UB,[],GDSGE_SIZE_STATE{:}),'coefs',[],'order',[2*ones(1,length(GDSGE_SIZE_STATE))],'Method',[],'ExtrapolationOrder',[2*ones(1,length(GDSGE_SIZE_STATE))],'thread',NumThreads,'orient','curvefit');
        GDSGE_UB_interp=myppual(GDSGE_UB_interp);
        
        v2struct(GDSGE_TEMP);
        GDSGE_SOL = reshape(myppual(GDSGE_SOL_interp,[GDSGE_TENSOR_shockIdx(:)';GDSGE_TENSOR_K(:)'; ]),size(GDSGE_SOL));
        GDSGE_LB_NEW = reshape(myppual(GDSGE_LB_interp,[GDSGE_TENSOR_shockIdx(:)';GDSGE_TENSOR_K(:)'; ]),size(GDSGE_LB));
        GDSGE_UB_NEW = reshape(myppual(GDSGE_UB_interp,[GDSGE_TENSOR_shockIdx(:)';GDSGE_TENSOR_K(:)'; ]),size(GDSGE_UB));
        
        
        else
            if isfield(GDSGE_OPTIONS.WarmUp.GDSGE_PROB,'GDSGE_SOL')
            GDSGE_SOL = GDSGE_OPTIONS.WarmUp.GDSGE_PROB.GDSGE_SOL;
            end
            
            if isfield(GDSGE_OPTIONS.WarmUp.GDSGE_PROB,'GDSGE_LB')
            GDSGE_LB = GDSGE_OPTIONS.WarmUp.GDSGE_PROB.GDSGE_LB;
            end
            
            if isfield(GDSGE_OPTIONS.WarmUp.GDSGE_PROB,'GDSGE_UB')
            GDSGE_UB = GDSGE_OPTIONS.WarmUp.GDSGE_PROB.GDSGE_UB;
            end
        end
    end
end

stopFlag = false;
tic;
while(~stopFlag)
    GDSGE_Iter = GDSGE_Iter+1;
    
    

    
GDSGE_DATA(:) = [repmat([shock_num;beta(:);sigma(:);alpha(:);delta(:);shock_trans(:);z(:); ],1,GDSGE_NPROB);GDSGE_TENSOR_shockIdx(:)';GDSGE_TENSOR_K(:)';   ];

MEX_TASK_NAME = MEX_TASK_INF_HORIZON;
GDSGE_F(:) = 1e20;
GDSGE_SKIP(:) = 0;
if exist('GDSGE_Iter','var')>0 && GDSGE_Iter>1
    GDSGE_USE_BROYDEN_NOW = GDSGE_USE_BROYDEN;
end

[GDSGE_SOL,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL,GDSGE_OPT_INFO] = mex_rbc(GDSGE_SOL,GDSGE_LB,GDSGE_UB,GDSGE_DATA,GDSGE_SKIP,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL);

NeedResolved = (GDSGE_F>TolSol) | isnan(GDSGE_F);
GDSGE_USE_BROYDEN_NOW = 0;
% Randomzie for nonconvert point
GDSGE_MinorIter = 0;
numNeedResolvedAfter = inf;
while ((max(isnan(GDSGE_F)) || max(GDSGE_F(:))>TolSol) && GDSGE_MinorIter<MaxMinorIter)
    % Repeatedly use the nearest point as initial guess
    NeedResolved = (GDSGE_F>TolSol) | isnan(GDSGE_F);
    numNeedResolved = sum(NeedResolved);
    while numNeedResolvedAfter ~= numNeedResolved
        NeedResolved = (GDSGE_F>TolSol) | isnan(GDSGE_F);
        numNeedResolved = sum(NeedResolved);
        % Use the nearest point as initial guess
        for i_dim = 1:length(GDSGE_SIZE)
            stride = prod(GDSGE_SIZE(1:i_dim-1));
            
            NeedResolved = (GDSGE_F>TolSol) | isnan(GDSGE_F);
            GDSGE_SKIP(:) = 1;
            for GDSGE_i = 1:numel(GDSGE_F)
                if NeedResolved(GDSGE_i) && GDSGE_i-stride>=1
                    GDSGE_idx = GDSGE_i-stride;
                    if ~NeedResolved(GDSGE_idx)
                        GDSGE_SOL(:,GDSGE_i) = GDSGE_SOL(:,GDSGE_idx);
                        GDSGE_SKIP(GDSGE_i) = 0;
                    end
                end
            end
            
            [GDSGE_SOL,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL,GDSGE_OPT_INFO] = mex_rbc(GDSGE_SOL,GDSGE_LB,GDSGE_UB,GDSGE_DATA,GDSGE_SKIP,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL);
            
            
            NeedResolved = (GDSGE_F>TolSol) | isnan(GDSGE_F);
            GDSGE_SKIP(:) = 1;
            for GDSGE_i = 1:numel(GDSGE_F)
                if NeedResolved(GDSGE_i) && GDSGE_i+stride<=numel(GDSGE_F)
                    GDSGE_idx = GDSGE_i+stride;
                    if ~NeedResolved(GDSGE_idx)
                        GDSGE_SOL(:,GDSGE_i) = GDSGE_SOL(:,GDSGE_idx);
                        GDSGE_SKIP(GDSGE_i) = 0;
                    end
                end
            end
            
            [GDSGE_SOL,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL,GDSGE_OPT_INFO] = mex_rbc(GDSGE_SOL,GDSGE_LB,GDSGE_UB,GDSGE_DATA,GDSGE_SKIP,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL);
            
        end
        
        NeedResolvedAfter = (GDSGE_F>TolSol) | isnan(GDSGE_F);
        numNeedResolvedAfter = sum(NeedResolvedAfter);
    end
    
    % Use randomize as initial guess
    GDSGE_X0Rand = rand(size(GDSGE_SOL)) .* (GDSGE_UB-GDSGE_LB) + GDSGE_LB;
    NeedResolved = (GDSGE_F>TolSol) | isnan(GDSGE_F);
    GDSGE_SOL(:,NeedResolved) = GDSGE_X0Rand(:,NeedResolved);
    GDSGE_SKIP(:) = 0;
    GDSGE_SKIP(~NeedResolved) = 1;
    
    
    [GDSGE_SOL,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL,GDSGE_OPT_INFO] = mex_rbc(GDSGE_SOL,GDSGE_LB,GDSGE_UB,GDSGE_DATA,GDSGE_SKIP,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL);
    
    
    if UseAdaptiveBoundInSol==1 && exist('GDSGE_Iter','var')>0
        % Tentatively adjust the bound
        GDSGE_LB_OLD = GDSGE_LB;
        GDSGE_UB_OLD = GDSGE_UB;
        
        
        
        
        % Hitting lower bound
        GDSGE_SOL_hitting_lower_bound = abs(GDSGE_SOL - GDSGE_LB_OLD) < 1e-8;
        GDSGE_SOL_hitting_upper_bound = abs(GDSGE_SOL - GDSGE_UB_OLD) < 1e-8;
        
        % Adjust for those hitting lower bound or upper bound
        GDSGE_LB(~GDSGE_SOL_hitting_lower_bound) = GDSGE_LB_OLD(~GDSGE_SOL_hitting_lower_bound);
        GDSGE_UB(~GDSGE_SOL_hitting_upper_bound) = GDSGE_UB_OLD(~GDSGE_SOL_hitting_upper_bound);
        
        GDSGE_MinorIter = GDSGE_MinorIter+1;
    end
    
    GDSGE_MinorIter = GDSGE_MinorIter+1;
end

c=GDSGE_SOL(1:1,:);
K_next=GDSGE_SOL(2:2,:);


w=GDSGE_AUX(1,:);

    
    
    
    c=reshape(c,shock_num,[]);
K_next=reshape(K_next,shock_num,[]);
w=reshape(w,shock_num,[]);

    
    GDSGE_NEW_c_interp = c;

    
    % Compute Metric
    try
        GDSGE_Metric = max([max(abs(GDSGE_NEW_c_interp(:)-c_interp(:)))]);

    catch
        GDSGE_Metric = nan;
    end
    
    GDSGE_Metric0 = GDSGE_Metric;
    
    if IS_WARMUP_LOOP==1
%         GDSGE_Metric = inf;
        IS_WARMUP_LOOP = 0;
    end
    
    % Update
    c_interp=GDSGE_NEW_c_interp;

    
    
    
    
    
    stopFlag = (isempty(GDSGE_Metric) || GDSGE_Metric<TolEq) || GDSGE_Iter>=MaxIter;
    
    GDSGE_INTERP_ORDER = INTERP_ORDER*ones(1,length(GDSGE_SIZE_STATE));
GDSGE_EXTRAP_ORDER = EXTRAP_ORDER*ones(1,length(GDSGE_SIZE_STATE));

GDSGE_PP_c_interp=struct('form','pp','breaks',{{K}},'Values',reshape(c_interp,[],GDSGE_SIZE_STATE{:}),'coefs',[],'order',GDSGE_INTERP_ORDER,'Method',[],'ExtrapolationOrder',GDSGE_EXTRAP_ORDER,'thread',NumThreads,'orient','curvefit');
GDSGE_PP_c_interp=myppual(myppual(GDSGE_PP_c_interp));



% Construct the vectorized spline
if ~GDSGE_USE_OLD_VEC
    GDSGE_SPLINE_VEC = convert_to_interp_eval_array({GDSGE_PP_c_interp});
end

    
    if ( ~NoPrint && (mod(GDSGE_Iter,PrintFreq)==0 || stopFlag == true) )
      fprintf(['Iter:%d, Metric:%g, maxF:%g\n'],GDSGE_Iter,GDSGE_Metric,max(GDSGE_F));
      toc;
      tic;
    end
    
    if ( (mod(GDSGE_Iter,SaveFreq)==0 || stopFlag == true) )
        c=reshape(c,GDSGE_SIZE);
K_next=reshape(K_next,GDSGE_SIZE);
c_interp=reshape(c_interp,GDSGE_SIZE);
w=reshape(w,GDSGE_SIZE);

        
        if CONSTRUCT_OUTPUT==1
        % Construct output variables
outputVarStack = cat(1,reshape(c,1,[]),reshape(w,1,[]));

% Permute variables from order (shock, var, states) to order (var,
% shock, states)
if shock_num>1
    outputVarStack = reshape(outputVarStack, [],shock_num,GDSGE_SIZE_STATE{:});
    output_interp=struct('form','MKL','breaks',{{1:shock_num,K}},...
        'Values',outputVarStack,...
        'coefs',[],'order',[2 OutputInterpOrder*ones(1,length({K}))],'Method',[],...
        'ExtrapolationOrder',[],'thread',NumThreads, ...
        'orient','curvefit');
else
    outputVarStack = reshape(outputVarStack, [],GDSGE_SIZE_STATE{:});
    output_interp=struct('form','MKL','breaks',{{K}},...
        'Values',outputVarStack,...
        'coefs',[],'order',[OutputInterpOrder*ones(1,length({K}))],'Method',[],...
        'ExtrapolationOrder',[],'thread',NumThreads, ...
        'orient','curvefit');
end
IterRslt.output_interp=myppual(output_interp);

output_var_index=struct();
output_var_index.c=1:1;
output_var_index.w=2:2;

IterRslt.output_var_index = output_var_index;
        end
        
        if CONSTRUCT_OUTPUT==1
        IterRslt.shock_num = shock_num;
        IterRslt.shock_trans = shock_trans;
        IterRslt.params = v2struct(beta,sigma,alpha,delta,GDSGE_EMPTY);
        IterRslt.var_shock = v2struct(z);
        IterRslt.var_policy = get_scalar(v2struct(c,K_next),{[1:shock_num],K});
        IterRslt.var_aux = get_scalar(v2struct(w,GDSGE_EMPTY),{[1:shock_num],K});
        IterRslt.var_tensor = v2struct(GDSGE_EMPTY);
        IterRslt.pp = v2struct(GDSGE_PP_c_interp,GDSGE_SPLINE_VEC,GDSGE_EMPTY);
        end
        IterRslt.Metric0 = GDSGE_Metric0;
        IterRslt.Metric = GDSGE_Metric;
        IterRslt.Iter = GDSGE_Iter;
        IterRslt.var_state = v2struct(K);
        IterRslt.var_interp = v2struct(c_interp);
        IterRslt.GDSGE_PROB = v2struct(GDSGE_LB,GDSGE_UB,GDSGE_SOL,GDSGE_F,GDSGE_SIZE);
        IterRslt.var_others = v2struct(GDSGE_EMPTY);
        IterRslt.NeedResolved = NeedResolved;

        if ~NoSave
            if IterSaveAll
                save(['IterRslt_rbc_' num2str(GDSGE_Iter) '.mat']);
            else
                save(['IterRslt_rbc_' num2str(GDSGE_Iter) '.mat'],'IterRslt');
            end
        end
    end
end
    

%% Return the success flag
IterFlag = 0;
end
