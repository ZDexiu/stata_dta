// This file is a part of GDSGE. License is Apache License, Version 2.0: http://github.com/gdsge/gdsge/LICENSE

#ifndef _HAS_CONDITIONAL_EXPLICIT
#if defined(__CUDACC__)
#define _HAS_CONDITIONAL_EXPLICIT 0 // TRANSITION
#elif defined(__INTEL_COMPILER)
#define _HAS_CONDITIONAL_EXPLICIT 0
#elif defined(__EDG__)
#define _HAS_CONDITIONAL_EXPLICIT 1
#elif defined(__clang__)
#define _HAS_CONDITIONAL_EXPLICIT 0 // TRANSITION, Clang 9
#else // vvv C1XX vvv
#define _HAS_CONDITIONAL_EXPLICIT 1
#endif // ^^^ C1XX ^^^
#endif // _HAS_CONDITIONAL_EXPLICIT

#define ADEPT_REMOVE_NULL_STATEMENTS 1

#define MAX_STACK_DIM 10000

#include "mex.h"
#include "adept_extension.h"
#include "mm_lite.h"
#include "codosol.h"
#include "interp_lite.h"
#include "MatlabPp.h"
#include "MatlabInterpEval.h"
#include "cmath"

#include<vector>
using std::vector;

#ifndef NO_OMP
#include "omp.h"
#endif

#include "wl_math.h"
#ifdef USE_ASG
  #include "class_handle.hpp"
  #include "asg_adouble.h"
  using namespace AdaptiveSparseGridInterp;
#endif



using adept::adouble;
using adept::Stack;

#ifdef HAS_INIT
void task_init(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
#endif

void task_inf_horizon(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  GET_INT(MEX_TASK_NAME);
  GET_INT(MEX_TASK_INIT);
  GET_INT(MEX_TASK_INF_HORIZON);

#ifdef HAS_INIT  
  if (MEX_TASK_NAME==MEX_TASK_INIT)
  {
    task_init(nlhs, plhs, nrhs, prhs);
    return;
  }
#endif
  
  if (MEX_TASK_NAME==MEX_TASK_INF_HORIZON)
  {
    task_inf_horizon(nlhs, plhs, nrhs, prhs);
    return;
  }
  
  mexErrMsgTxt("No mex task executed.");
}

#ifdef HAS_INIT
// This file is a part of GDSGE. License is Apache License, Version 2.0: http://github.com/gdsge/gdsge/LICENSE
void task_init(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  GET_DBL(TolFun);
  GET_DBL(TolSol);
  GET_INT(SolMaxIter);
  GET_INT(NumThreads);
  GET_INT(GDSGE_DEBUG_EVAL_ONLY);
  GET_INT(UseBroyden);
  GET_DBL(FiniteDiffDelta);
  GET_INT(GDSGE_USE_BROYDEN_NOW);

  #ifndef NO_OMP
  omp_set_num_threads(NumThreads);
  #endif
  
  // 
  int GDSGE_NPROB = mxGetN(prhs[3]);
  int GDSGE_NUM_SOL0 = mxGetN(prhs[0]);

  // Input
  GET_DM_VIEW_FROM_MX(GDSGE_SOL0,prhs[0]);
  GET_DM_VIEW_FROM_MX(GDSGE_LB,prhs[1]);
  GET_DM_VIEW_FROM_MX(GDSGE_UB,prhs[2]);
  GET_DM_VIEW_FROM_MX(GDSGE_DATA,prhs[3]);
  GET_DV_VIEW_FROM_MX(GDSGE_SKIP,prhs[4]);
  GET_DV_VIEW_FROM_MX(GDSGE_F0,prhs[5]);
  GET_DM_VIEW_FROM_MX(GDSGE_AUX0,prhs[6]);
  GET_DM_VIEW_FROM_MX(GDSGE_EQVAL0,prhs[7]);
  
  // Output
  plhs[0] = mxCreateDoubleMatrix(0,GDSGE_NPROB,mxREAL);
  plhs[1] = mxCreateDoubleMatrix(1,GDSGE_NPROB,mxREAL);
  plhs[2] = mxCreateDoubleMatrix(0,GDSGE_NPROB,mxREAL);
  plhs[3] = mxCreateDoubleMatrix(0,GDSGE_NPROB,mxREAL);
  plhs[4] = mxCreateDoubleMatrix(1,GDSGE_NPROB,mxREAL);
  
  GET_DM_VIEW_FROM_MX(GDSGE_SOL,plhs[0]);
  GET_DV_VIEW_FROM_MX(GDSGE_F,plhs[1]);
  GET_DM_VIEW_FROM_MX(GDSGE_AUX,plhs[2]);
  GET_DM_VIEW_FROM_MX(GDSGE_EQVAL,plhs[3]);
  GET_DV_VIEW_FROM_MX(GDSGE_OPT_INFO,plhs[4]);
  
  // Input and output
  ;
  
#pragma omp parallel for schedule(dynamic)
	for (int GDSGE_I = 1; GDSGE_I <= GDSGE_NPROB; GDSGE_I++)
	{
        ;
        
    GDSGE_F(GDSGE_I) = GDSGE_F0(GDSGE_I);
    if (GDSGE_SKIP(GDSGE_I) == 1)
    { 
      memcpy(&GDSGE_SOL(1,GDSGE_I), &GDSGE_SOL0(1,GDSGE_I), sizeof(double)*0);
      memcpy(&GDSGE_EQVAL(1,GDSGE_I), &GDSGE_EQVAL0(1,GDSGE_I), sizeof(double)*0);
      memcpy(&GDSGE_AUX(1,GDSGE_I), &GDSGE_AUX0(1,GDSGE_I), sizeof(double)*0);
			continue;
    }
    
    //Initiate adept
    Stack _stack;
	int GDSGE_EVAL_GRAD_FLAG = 0;
  
    ;

		double* GDSGE_data = &GDSGE_DATA(1, GDSGE_I);
		double* GDSGE_aux = &GDSGE_AUX(1, GDSGE_I);
		double* GDSGE_eqval = &GDSGE_EQVAL(1, GDSGE_I);

	int GDSGE_POP_I = 0;
#define POPN(var) double var = GDSGE_data[GDSGE_POP_I++]
#define POPNARRAY(var, length) double* var = &GDSGE_data[GDSGE_POP_I]; GDSGE_POP_I+=length
#define POPNARRAY_BASE1(var, length) double* var = &GDSGE_data[GDSGE_POP_I-1]; GDSGE_POP_I+=length

		POPN(GDSGE_NUM_SHOCKS_D);
int GDSGE_NUM_SHOCKS = (int) GDSGE_NUM_SHOCKS_D;
POPN(beta);
POPN(sigma);
POPN(alpha);
POPN(delta);
POPNARRAY(GDSGE_shock_trans,2*2);
#define shock_trans(idx) GDSGE_shock_trans[int(idx)-1]
POPNARRAY(z_GDSGE_GRID,2);
#define z_GRID(idx) z_GDSGE_GRID[int(idx)-1]
POPN(GDSGE_shockIdx_d);
int shock = (int)GDSGE_shockIdx_d;
double z = z_GRID(shock);
POPN(K);
;
        
        ;
    
    ;
    
    
    
    ;
	}
}
#endif

// This file is a part of GDSGE. License is Apache License, Version 2.0: http://github.com/gdsge/gdsge/LICENSE
void task_inf_horizon(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  GET_DBL(TolFun);
  GET_DBL(TolSol);
  GET_INT(SolMaxIter);
  GET_INT(NumThreads);
  GET_INT(GDSGE_DEBUG_EVAL_ONLY);
  GET_INT(UseBroyden);
  GET_DBL(FiniteDiffDelta);
  GET_INT(GDSGE_USE_BROYDEN_NOW);

  #ifndef NO_OMP
  omp_set_num_threads(NumThreads);
  #endif
  
  // 
  int GDSGE_NPROB = mxGetN(prhs[3]);
  int GDSGE_NUM_SOL0 = mxGetN(prhs[0]);

  // Input
  GET_DM_VIEW_FROM_MX(GDSGE_SOL0,prhs[0]);
  GET_DM_VIEW_FROM_MX(GDSGE_LB,prhs[1]);
  GET_DM_VIEW_FROM_MX(GDSGE_UB,prhs[2]);
  GET_DM_VIEW_FROM_MX(GDSGE_DATA,prhs[3]);
  GET_DV_VIEW_FROM_MX(GDSGE_SKIP,prhs[4]);
  GET_DV_VIEW_FROM_MX(GDSGE_F0,prhs[5]);
  GET_DM_VIEW_FROM_MX(GDSGE_AUX0,prhs[6]);
  GET_DM_VIEW_FROM_MX(GDSGE_EQVAL0,prhs[7]);
  
  // Output
  plhs[0] = mxCreateDoubleMatrix(2,GDSGE_NPROB,mxREAL);
  plhs[1] = mxCreateDoubleMatrix(1,GDSGE_NPROB,mxREAL);
  plhs[2] = mxCreateDoubleMatrix(1,GDSGE_NPROB,mxREAL);
  plhs[3] = mxCreateDoubleMatrix(2,GDSGE_NPROB,mxREAL);
  plhs[4] = mxCreateDoubleMatrix(1,GDSGE_NPROB,mxREAL);
  
  GET_DM_VIEW_FROM_MX(GDSGE_SOL,plhs[0]);
  GET_DV_VIEW_FROM_MX(GDSGE_F,plhs[1]);
  GET_DM_VIEW_FROM_MX(GDSGE_AUX,plhs[2]);
  GET_DM_VIEW_FROM_MX(GDSGE_EQVAL,plhs[3]);
  GET_DV_VIEW_FROM_MX(GDSGE_OPT_INFO,plhs[4]);
  
  // Input and output
  GET_STRUCT(GDSGE_SPLINE_VEC);
MatlabInterpEval<1,1> GDSGE_CSPLINE_VEC(GDSGE_SPLINE_VEC);
GET_STRUCT(GDSGE_PP_c_interp);
MatlabPp<1,4> GDSGE_CPP_c_interp(GDSGE_PP_c_interp);
auto c_interp_adouble = [&GDSGE_CPP_c_interp](int shockIdx, adouble K)
{
  adouble xSite[] = {K};
  int GDSGE_INTERP_CELL[1];
  return GDSGE_CPP_c_interp.eval_4(xSite, GDSGE_INTERP_CELL, shockIdx-1);
};

auto c_interp_double = [&GDSGE_CPP_c_interp](int shockIdx, double K)
{
  double xSite[] = {K};
  int GDSGE_INTERP_CELL[1];
  return GDSGE_CPP_c_interp.eval_4(xSite, GDSGE_INTERP_CELL, shockIdx-1);
};

;
  
#pragma omp parallel for schedule(dynamic)
	for (int GDSGE_I = 1; GDSGE_I <= GDSGE_NPROB; GDSGE_I++)
	{
        ;
        
    GDSGE_F(GDSGE_I) = GDSGE_F0(GDSGE_I);
    if (GDSGE_SKIP(GDSGE_I) == 1)
    { 
      memcpy(&GDSGE_SOL(1,GDSGE_I), &GDSGE_SOL0(1,GDSGE_I), sizeof(double)*2);
      memcpy(&GDSGE_EQVAL(1,GDSGE_I), &GDSGE_EQVAL0(1,GDSGE_I), sizeof(double)*2);
      memcpy(&GDSGE_AUX(1,GDSGE_I), &GDSGE_AUX0(1,GDSGE_I), sizeof(double)*1);
			continue;
    }
    
    //Initiate adept
    Stack _stack;
	int GDSGE_EVAL_GRAD_FLAG = 0;
  
    int GDSGE_INTERP_CELL[1] = { 0 };
adouble GDSGE_INTERP_RSLT_adouble[1] = {0};
double GDSGE_INTERP_RSLT_double[1] = {0};
bool INTERP_VEC_FLAG[1] = {false};
double GDSGE_INTERP_GRAD[1*1] = { 0 };

#ifdef GDSGE_USE_OLD_VEC
// Vector evaluation
auto GDSGE_INTERP_VEC = [&GDSGE_XSITE_TO_LEFT,&GDSGE_INTERP_CELL,&GDSGE_INTERP_RSLT,&INTERP_VEC_FLAG,
  &GDSGE_CPP_c_interp](int shockIdx, double K)
{
  // Search once
  adouble xSite[] = {K};
  bool hasSearched=false;
  int rsltIdx = 0;
  int interpIdx = 0;

  GDSGE_CPP_c_interp.search(xSite, GDSGE_INTERP_CELL, GDSGE_XSITE_TO_LEFT);
  
  //
  if (INTERP_VEC_FLAG[interpIdx++]) {
  if (!hasSearched) { GDSGE_CPP_c_interp.search(xSite, GDSGE_INTERP_CELL, GDSGE_XSITE_TO_LEFT); hasSearched=true; }
  GDSGE_INTERP_RSLT[rsltIdx++]=GDSGE_CPP_c_interp.nosearch_eval_4(GDSGE_XSITE_TO_LEFT, GDSGE_INTERP_CELL, shockIdx-1);
}


};
#endif

// Vector evaluation
auto GDSGE_INTERP_VEC_adouble = [&GDSGE_CSPLINE_VEC,&GDSGE_INTERP_RSLT_adouble,&GDSGE_INTERP_GRAD,&GDSGE_INTERP_CELL,&GDSGE_EVAL_GRAD_FLAG] (int shockIdx, adouble K)
{
  // Search once
  adouble xSite[] = {K};

  GDSGE_CSPLINE_VEC.search_eval_vec_at_array_adouble(shockIdx - 1, xSite, GDSGE_INTERP_RSLT_adouble, GDSGE_INTERP_GRAD, GDSGE_INTERP_CELL, GDSGE_EVAL_GRAD_FLAG);
};

// Vector evaluation
auto GDSGE_INTERP_VEC_double = [&GDSGE_CSPLINE_VEC,&GDSGE_INTERP_RSLT_double,&GDSGE_INTERP_CELL,&GDSGE_EVAL_GRAD_FLAG] (int shockIdx, double K)
{
  // Search once
  double xSite[] = {K};

  GDSGE_CSPLINE_VEC.search_eval_vec_at_array(shockIdx - 1, xSite, GDSGE_INTERP_RSLT_double, GDSGE_INTERP_CELL);
};

;

		double* GDSGE_data = &GDSGE_DATA(1, GDSGE_I);
		double* GDSGE_aux = &GDSGE_AUX(1, GDSGE_I);
		double* GDSGE_eqval = &GDSGE_EQVAL(1, GDSGE_I);

	int GDSGE_POP_I = 0;
#define POPN(var) double var = GDSGE_data[GDSGE_POP_I++]
#define POPNARRAY(var, length) double* var = &GDSGE_data[GDSGE_POP_I]; GDSGE_POP_I+=length
#define POPNARRAY_BASE1(var, length) double* var = &GDSGE_data[GDSGE_POP_I-1]; GDSGE_POP_I+=length

		POPN(GDSGE_NUM_SHOCKS_D);
int GDSGE_NUM_SHOCKS = (int) GDSGE_NUM_SHOCKS_D;
POPN(beta);
POPN(sigma);
POPN(alpha);
POPN(delta);
POPNARRAY(GDSGE_shock_trans,2*2);
#define shock_trans(idx) GDSGE_shock_trans[int(idx)-1]
POPNARRAY(z_GDSGE_GRID,2);
#define z_GRID(idx) z_GDSGE_GRID[int(idx)-1]
POPN(GDSGE_shockIdx_d);
int shock = (int)GDSGE_shockIdx_d;
double z = z_GRID(shock);
POPN(K);
;
        
        double ;
#if MAXDIM>MAX_STACK_DIM
vector<double> ;
vector<double> ;
#else
double ;
double ;
#endif

;
    
    
		auto GDSGE_FUNC_1_adouble = [&](adouble* GDSGE_x, adouble* GDSGE_EQ, int GDSGE_EVAL=0)
		{
			adouble& c = GDSGE_x[0];
adouble& K_next = GDSGE_x[1];
;

			adouble euler_residual(0), market_clear(0), u_prime(0), w(0);
#if MAXDIM>MAX_STACK_DIM
vector<adouble> c_future_GDSGE_GRID(2), kret_next_GDSGE_GRID(2), u_prime_future_GDSGE_GRID(2);
vector<adouble> ;
#else
adouble c_future_GDSGE_GRID[2], kret_next_GDSGE_GRID[2], u_prime_future_GDSGE_GRID[2];
adouble ;
#endif
#define kret_next_GRID(idx) kret_next_GDSGE_GRID[int(idx)-1]
#define kret_next(idx) kret_next_GDSGE_GRID[int(idx)-1]
#define c_future_GRID(idx) c_future_GDSGE_GRID[int(idx)-1]
#define c_future(idx) c_future_GDSGE_GRID[int(idx)-1]
#define u_prime_future_GRID(idx) u_prime_future_GDSGE_GRID[int(idx)-1]
#define u_prime_future(idx) u_prime_future_GDSGE_GRID[int(idx)-1]
;

			
  u_prime = pow(c,-sigma); //parsed from gmod Line:   u_prime = c^(-sigma);
for(int GDSGE_iter=1; GDSGE_iter<=2; GDSGE_iter++)
{
  kret_next_GDSGE_GRID[GDSGE_iter-1] = -delta+pow(K_next,alpha-1.0)*alpha*z_GDSGE_GRID[GDSGE_iter-1]+1.0; //parsed from gmod Line:   kret_next' = z'*alpha*K_next^(alpha-1) + 1-delta;
}
for(int GDSGE_iter=1; GDSGE_iter<=2; GDSGE_iter++)
{
  c_future_GDSGE_GRID[GDSGE_iter-1] = c_interp_adouble(GDSGE_iter,K_next); //parsed from gmod Line:   c_future' = c_interp_adouble'(K_next);
}
for(int GDSGE_iter=1; GDSGE_iter<=2; GDSGE_iter++)
{
  u_prime_future_GDSGE_GRID[GDSGE_iter-1] = pow(c_future_GDSGE_GRID[GDSGE_iter-1],-sigma); //parsed from gmod Line:   u_prime_future' = c_future'^(-sigma);
}
adouble GDSGE_REDUCTION_VALUE0=0;
for(int GDSGE_iter=1; GDSGE_iter<=2; GDSGE_iter++)
{
  GDSGE_REDUCTION_VALUE0 = GDSGE_REDUCTION_VALUE0+shock_trans(GDSGE_iter*2.0+shock-2.0)*kret_next_GDSGE_GRID[GDSGE_iter-1]*u_prime_future_GDSGE_GRID[GDSGE_iter-1];
}
  euler_residual = -(GDSGE_REDUCTION_VALUE0*beta)/u_prime+1.0; //parsed from gmod Line:   euler_residual = 1 - beta*GDSGE_EXPECT{u_prime_future'*kret_next'}/u_prime;

  market_clear = -K_next-c-K*(delta-1.0)+pow(K,alpha)*z; //parsed from gmod Line:   market_clear = z*K^alpha + (1-delta)*K - c - K_next;

  w = -pow(K,alpha)*z*(alpha-1.0); //parsed from gmod Line:   w = z*(1-alpha)*K^alpha;
;

			GDSGE_aux[0]=value(w);
;

			  GDSGE_EQ[0] = euler_residual; //parsed from gmod Line: euler_residual;
  GDSGE_EQ[1] = market_clear; //parsed from gmod Line: market_clear;
;

			for (int i = 0; i < 2; ++i)
			{
				GDSGE_eqval[i] = value(GDSGE_EQ[i]);
			}
		};
		auto GDSGE_FUNC_1_double = [&](double* GDSGE_x, double* GDSGE_EQ, int GDSGE_EVAL=0)
		{
			double& c = GDSGE_x[0];
double& K_next = GDSGE_x[1];
;

			double euler_residual(0), market_clear(0), u_prime(0), w(0);
#if MAXDIM>MAX_STACK_DIM
vector<double> c_future_GDSGE_GRID(2), kret_next_GDSGE_GRID(2), u_prime_future_GDSGE_GRID(2);
vector<double> ;
#else
double c_future_GDSGE_GRID[2], kret_next_GDSGE_GRID[2], u_prime_future_GDSGE_GRID[2];
double ;
#endif
#define kret_next_GRID(idx) kret_next_GDSGE_GRID[int(idx)-1]
#define kret_next(idx) kret_next_GDSGE_GRID[int(idx)-1]
#define c_future_GRID(idx) c_future_GDSGE_GRID[int(idx)-1]
#define c_future(idx) c_future_GDSGE_GRID[int(idx)-1]
#define u_prime_future_GRID(idx) u_prime_future_GDSGE_GRID[int(idx)-1]
#define u_prime_future(idx) u_prime_future_GDSGE_GRID[int(idx)-1]
;

			
  u_prime = pow(c,-sigma); //parsed from gmod Line:   u_prime = c^(-sigma);
for(int GDSGE_iter=1; GDSGE_iter<=2; GDSGE_iter++)
{
  kret_next_GDSGE_GRID[GDSGE_iter-1] = -delta+pow(K_next,alpha-1.0)*alpha*z_GDSGE_GRID[GDSGE_iter-1]+1.0; //parsed from gmod Line:   kret_next' = z'*alpha*K_next^(alpha-1) + 1-delta;
}
for(int GDSGE_iter=1; GDSGE_iter<=2; GDSGE_iter++)
{
  c_future_GDSGE_GRID[GDSGE_iter-1] = c_interp_double(GDSGE_iter,K_next); //parsed from gmod Line:   c_future' = c_interp_double'(K_next);
}
for(int GDSGE_iter=1; GDSGE_iter<=2; GDSGE_iter++)
{
  u_prime_future_GDSGE_GRID[GDSGE_iter-1] = pow(c_future_GDSGE_GRID[GDSGE_iter-1],-sigma); //parsed from gmod Line:   u_prime_future' = c_future'^(-sigma);
}
double GDSGE_REDUCTION_VALUE0=0;
for(int GDSGE_iter=1; GDSGE_iter<=2; GDSGE_iter++)
{
  GDSGE_REDUCTION_VALUE0 = GDSGE_REDUCTION_VALUE0+shock_trans(GDSGE_iter*2.0+shock-2.0)*kret_next_GDSGE_GRID[GDSGE_iter-1]*u_prime_future_GDSGE_GRID[GDSGE_iter-1];
}
  euler_residual = -(GDSGE_REDUCTION_VALUE0*beta)/u_prime+1.0; //parsed from gmod Line:   euler_residual = 1 - beta*GDSGE_EXPECT{u_prime_future'*kret_next'}/u_prime;

  market_clear = -K_next-c-K*(delta-1.0)+pow(K,alpha)*z; //parsed from gmod Line:   market_clear = z*K^alpha + (1-delta)*K - c - K_next;

  w = -pow(K,alpha)*z*(alpha-1.0); //parsed from gmod Line:   w = z*(1-alpha)*K^alpha;
;

			GDSGE_aux[0]=value(w);
;

			  GDSGE_EQ[0] = euler_residual; //parsed from gmod Line: euler_residual;
  GDSGE_EQ[1] = market_clear; //parsed from gmod Line: market_clear;
;

			for (int i = 0; i < 2; ++i)
			{
				GDSGE_eqval[i] = value(GDSGE_EQ[i]);
			}
		};
        auto GDSGE_OBJ_1 = [&](double* GDSGE_x, double* GDSGE_f, double* GDSGE_jac)
		{
            if (GDSGE_jac == 0)
            {
                GDSGE_FUNC_1_double(&GDSGE_x[0], &GDSGE_f[0]);
            }
            else
            {
                #ifdef USE_FINITE_DIFF
                    GDSGE_FUNC_1_double(&GDSGE_x[0], &GDSGE_f[0]);
                    #if MAXDIM>MAX_STACK_DIM
                    vector<double> GDSGE_x_new(2);
                    vector<double> GDSGE_f_new(2);
                    #else
                    double GDSGE_x_new[2];
                    double GDSGE_f_new[2];
                    #endif
                    memcpy(&GDSGE_x_new[0], &GDSGE_x[0], sizeof(double)*2);
                    for (int i_var = 0; i_var < 2; ++i_var)
                    {
                        // Perturb
                        GDSGE_x_new[i_var] = GDSGE_x[i_var] + FiniteDiffDelta;
                        GDSGE_FUNC_1_double(&GDSGE_x_new[0], &GDSGE_f_new[0]);
                        
                        // Jacobian, eq goes first in memory
                        #define JAC(i_eq,i_var) GDSGE_jac[(i_eq) + 2*(i_var)] 
                        for (int i_eq = 0; i_eq < 2; ++i_eq)
                        {
                            JAC(i_eq,i_var) = (GDSGE_f_new[i_eq] - GDSGE_f[i_eq]) / FiniteDiffDelta;
                        }
                        #undef JAC
                        
                        // Revert
                        GDSGE_x_new[i_var] = GDSGE_x[i_var];
                    }
                #else
                    // Copy to adouble
                    #if MAXDIM>MAX_STACK_DIM
                    vector<adouble> GDSGE_x_adept(2);
                    vector<adouble> GDSGE_EQ(2);
                    #else
                    adouble GDSGE_x_adept[2];
                    adouble GDSGE_EQ[2];
                    #endif
                    for (int j = 0; j < 2; ++j)
                    {
                        GDSGE_x_adept[j] = GDSGE_x[j];
                    }
                    _stack.new_recording();
                    _stack.set_max_jacobian_threads(1);
                    GDSGE_EVAL_GRAD_FLAG = 1;

                    // Evaluate functions
                    GDSGE_FUNC_1_adouble(&GDSGE_x_adept[0], &GDSGE_EQ[0]);
                    if (GDSGE_f) {
                        for (int i = 0; i < 2 ; i++)
                        {
                            GDSGE_f[i] = GDSGE_EQ[i].value();
                        }
                    }
                    // Calculate jacobian
                    
                    
                    _stack.independent(&GDSGE_x_adept[0], 2);
                    _stack.dependent(&GDSGE_EQ[0], 2);
                    #ifdef __WIN32__
                    _stack.jacobian_forward_vec(GDSGE_jac);
                    #else
                    _stack.jacobian_forward(GDSGE_jac);
                    #endif
                    
                #endif
            }
		};;
    
    
// This file is a part of GDSGE. License is Apache License, Version 2.0: http://github.com/gdsge/gdsge/LICENSE
if (1) {
  if (GDSGE_DEBUG_EVAL_ONLY==0)
  {
    // Copy sol0 to sol
    memcpy(&GDSGE_SOL(1,GDSGE_I), &GDSGE_SOL0(1,GDSGE_I), sizeof(double)*2);

    GDSGE_F(GDSGE_I) = CoDoSol::solve(2, &GDSGE_SOL(1, GDSGE_I), &GDSGE_LB(1, GDSGE_I), &GDSGE_UB(1, GDSGE_I), UseBroyden, TolFun, 0, SolMaxIter, GDSGE_OBJ_1, &GDSGE_OPT_INFO(GDSGE_I));
  }
  else if (GDSGE_DEBUG_EVAL_ONLY==1)
  {
    memcpy(&GDSGE_SOL(1,GDSGE_I), &GDSGE_SOL0(1,GDSGE_I), sizeof(double)*2);
  }
  
  // Evaluate at the solution
  double* GDSGE_x = &GDSGE_SOL(1, GDSGE_I);
  #if MAXDIM>MAX_STACK_DIM
  vector<double> GDSGE_EQ(2);
  #else
  double GDSGE_EQ[2];
  #endif
  
  GDSGE_FUNC_1_double(&GDSGE_x[0], &GDSGE_EQ[0], 1);
}
    
    ;
	}
}
