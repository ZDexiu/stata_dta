% This file is a part of GDSGE. License is Apache License, Version 2.0: http://github.com/gdsge/gdsge/LICENSE
function SimuRslt = simulate_rbc(IterRslt,GDSGE_OPTIONS)
%% Add path
if ispc
    BLAS_FILE = 'essential_blas.dll';
    PATH_DELIMITER = ';';
    
    GDSGE_TOOLBOX_ROOT = fileparts(which(BLAS_FILE));
    if ~any(strcmp(strsplit(getenv('PATH'),PATH_DELIMITER),GDSGE_TOOLBOX_ROOT))
        setenv('PATH',[getenv('PATH'),PATH_DELIMITER,GDSGE_TOOLBOX_ROOT]);
    end
    
    clear BLAS_FILE PATH_DELIMITER GDSGE_TOOLBOX_ROOT
elseif ismac
    if exist('./essential_blas.dylib','file') == 0
        copyfile(which('essential_blas.dylib'),'./');
    end
end

%% Simulate code starts here
TolEq = 1e-6;
TolSol = 1e-8;
TolFun = 1e-8;
PrintFreq = 10;
NoPrint = 0;
SaveFreq = 10;
NoSave = 0;
SimuPrintFreq = 1000;
SimuSaveFreq = inf;
MaxIter = inf;
MaxMinorIter = inf;
num_samples = 1;
num_periods = 1000;
SolMaxIter = 200;

% task constants
MEX_TASK_INIT = 0;
MEX_TASK_INF_HORIZON = 1;

% Solver
UseBroyden = 0;
FiniteDiffDelta = 1e-6;

% DEBUG flag
GDSGE_DEBUG_EVAL_ONLY = 0;
GDSGE_USE_BROYDEN = 1;
GDSGE_USE_BROYDEN_NOW = 0;

v2struct(IterRslt.pp);

INTERP_ORDER = 4;
EXTRAP_ORDER = 2;
OutputInterpOrder = 2;
USE_SPLINE = 1;
GDSGE_USE_OLD_VEC = 0;
USE_ASG = 0;
USE_PCHIP = 0;
USE_SPARSE_JACOBIAN = 0;
SIMU_INTERP = 0;
SIMU_RESOLVE = 1;
SimuSeed = 0823;
AsgMinLevel = 4;
AsgMaxLevel = 10;
AsgThreshold = 1e-2;
AsgOutputMaxLevel = 10;
AsgOutputThreshold = 1e-2;
IterSaveAll = 0;
SkipModelInit = 0;
GDSGE_EMPTY = [];
GDSGE_ASG_FIX_GRID = 0;
UseModelId = 0;
MinBatchSol = 1;
UseAdaptiveBound = 1;
UseAdaptiveBoundInSol = 0;
EnforceSimuStateInbound = 1;
REMOVE_NULL_STATEMENTS = 0;
REUSE_WARMUP_SOL = 1;
INTERP_WARMUP_SOL = 1;
CONSTRUCT_OUTPUT = 1;
shock_num = 1;
shock_trans = 1;
NumThreads = feature('numcores');
GDSGE_dummy_state = zeros(1,NumThreads*4);
GDSGE_dummy_shock = 0;
USE_FINITE_DIFF = 0;
DEFAULT_PARAMETERS_END_HERE = true;
beta  = 0.99;
sigma = 2.0;
alpha = 0.36;
delta = 0.025;
shock_num = 2;
z_low = 0.99;
z_high = 1.01;
Pr_ll = 0.9;
Pr_hh  = 0.9;
z = [z_low,z_high];
shock_trans = [;
Pr_ll, 1-Pr_ll;
1-Pr_hh, Pr_hh;
];
Kss  = (alpha/(1/beta - 1 + delta))^(1/(1-alpha));
KPts = 101;
KMin = Kss*0.9;
KMax = Kss*1.1;
K    = linspace(KMin,KMax,KPts);
num_periods = 10000;
num_samples = 6;


GEN_SHOCK_START_PERIOD = 1;

shock_trans = IterRslt.shock_trans;
v2struct(IterRslt.params);
v2struct(IterRslt.var_shock);
v2struct(IterRslt.var_state);

if nargin>=2
    v2struct(GDSGE_OPTIONS)
end

%% Construct interpolation for solutions
if shock_num>1
    GDSGE_PP=struct('form','MKL','breaks',{{1:shock_num,K}},...
        'Values',reshape(IterRslt.GDSGE_PROB.GDSGE_SOL, [numel(IterRslt.GDSGE_PROB.GDSGE_SOL)/prod(IterRslt.GDSGE_PROB.GDSGE_SIZE),IterRslt.GDSGE_PROB.GDSGE_SIZE]),...
        'coefs',[],'order',[2 OutputInterpOrder*ones(1,length({K}))],'Method',[],...
        'ExtrapolationOrder',[],'thread',NumThreads, ...
        'orient','curvefit');
else
    GDSGE_PP=struct('form','MKL','breaks',{{K}},...
        'Values',reshape(IterRslt.GDSGE_PROB.GDSGE_SOL, [numel(IterRslt.GDSGE_PROB.GDSGE_SOL)/prod(IterRslt.GDSGE_PROB.GDSGE_SIZE),IterRslt.GDSGE_PROB.GDSGE_SIZE(2:end)]),...
        'coefs',[],'order',[OutputInterpOrder*ones(1,length({K}))],'Method',[],...
        'ExtrapolationOrder',[],'thread',NumThreads, ...
        'orient','curvefit');
end
GDSGE_PP=myppual(GDSGE_PP);

GDSGE_NPROB = num_samples;

SimuRslt.shock = ones(num_samples,num_periods+1);
SimuRslt.K=zeros(num_samples,num_periods);
SimuRslt.c=zeros(num_samples,num_periods);
SimuRslt.K=zeros(num_samples,num_periods);
SimuRslt.w=zeros(num_samples,num_periods);


SimuRslt.K(:,1)=Kss;
SimuRslt.shock(:,1)=1;


if nargin>1 && isfield(GDSGE_OPTIONS,'init')
    SimuRslt.K(:,1:size(GDSGE_OPTIONS.init.K,2))=GDSGE_OPTIONS.init.K;
SimuRslt.shock(:,1:size(GDSGE_OPTIONS.init.shock,2))=GDSGE_OPTIONS.init.shock;

end

if any(SimuRslt.shock(:,1)>shock_num)
    error('initial shock exceeds shock_num');
end

GDSGE_LB = zeros(2,GDSGE_NPROB);
GDSGE_UB = 1e3*ones(2,GDSGE_NPROB);
GDSGE_LB(1:1,:)=0;
GDSGE_LB(2:2,:)=0;



% Use the largest bound in IterSol
if UseAdaptiveBound==1
GDSGE_LB = repmat(min(IterRslt.GDSGE_PROB.GDSGE_LB,[],2),[1,GDSGE_NPROB]);
GDSGE_UB = repmat(max(IterRslt.GDSGE_PROB.GDSGE_UB,[],2),[1,GDSGE_NPROB]);
end

GDSGE_SKIP = zeros(1,GDSGE_NPROB);
GDSGE_EQVAL = 1e20*ones(2,GDSGE_NPROB);
GDSGE_F = 1e20*ones(1,GDSGE_NPROB);
GDSGE_SOL = zeros(2,GDSGE_NPROB);
GDSGE_AUX = zeros(1,GDSGE_NPROB);

%% Generate random number
SimuRslt.shock(:,GEN_SHOCK_START_PERIOD:end) = gen_discrete_markov_rn(shock_trans,num_samples,length(GEN_SHOCK_START_PERIOD:num_periods+1),...
    SimuRslt.shock(:,GEN_SHOCK_START_PERIOD));

MEX_TASK_NAME = MEX_TASK_INF_HORIZON;
GDSGE_SHOCK_VAR_INDEX_BASE = ([0:num_samples-1]')*shock_num;

tic;
for GDSGE_t=1:num_periods
    % Reuse the init inbound and tensor code
    % Map grid to current variable
    shock = SimuRslt.shock(:,GDSGE_t);
    K=SimuRslt.K(:,GDSGE_t);

    
    GDSGE_data0 = repmat([shock_num;beta(:);sigma(:);alpha(:);delta(:);shock_trans(:);z(:); ],1,GDSGE_NPROB);
    
    
    
    % Use interpolation as initial values
%     %{
    if GDSGE_t>0
        if shock_num>1
            GDSGE_SOL = myppual_mex(int32(NumThreads),GDSGE_PP.breaks,GDSGE_PP.coefs,...
                int32(GDSGE_PP.pieces),int32(GDSGE_PP.order),int32(GDSGE_PP.dim),'not-a-knot',[SimuRslt.shock(:,GDSGE_t)';SimuRslt.K(:,GDSGE_t)'],[],[],[]);
        else
            GDSGE_SOL = myppual_mex(int32(NumThreads),GDSGE_PP.breaks,GDSGE_PP.coefs,...
                int32(GDSGE_PP.pieces),int32(GDSGE_PP.order),int32(GDSGE_PP.dim),'not-a-knot',[SimuRslt.K(:,GDSGE_t)'],[],[],[]);
        end
    end
    %}
    
    if UseAdaptiveBoundInSol==1
        % Tentatively adjust the bound
        GDSGE_LB_OLD = GDSGE_LB;
        GDSGE_UB_OLD = GDSGE_UB;
        
        
        
        % Hitting lower bound
        GDSGE_SOL_hitting_lower_bound = abs(GDSGE_SOL - GDSGE_LB_OLD) < 1e-8;
        GDSGE_SOL_hitting_upper_bound = abs(GDSGE_SOL - GDSGE_UB_OLD) < 1e-8;
        
        % Adjust for those hitting lower bound or upper bound
        GDSGE_LB(~GDSGE_SOL_hitting_lower_bound) = GDSGE_LB_OLD(~GDSGE_SOL_hitting_lower_bound);
        GDSGE_UB(~GDSGE_SOL_hitting_upper_bound) = GDSGE_UB_OLD(~GDSGE_SOL_hitting_upper_bound);
    end

    % Construct tensor variable
    
    
    % Reconstruct data
    GDSGE_DATA = [GDSGE_data0;shock(:)';K(:)';   ];
    
    % Solve problems
    GDSGE_SKIP = zeros(1,GDSGE_NPROB);
    [GDSGE_SOL,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL,GDSGE_OPT_INFO] = mex_rbc(GDSGE_SOL,GDSGE_LB,GDSGE_UB,GDSGE_DATA,GDSGE_SKIP,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL);
    while (max(isnan(GDSGE_F)) || max(GDSGE_F(:))>TolSol)
        GDSGE_X0Rand = rand(size(GDSGE_SOL)) .* (GDSGE_UB-GDSGE_LB) + GDSGE_LB;
        NeedResolved = (GDSGE_F>TolSol) | isnan(GDSGE_F);
        GDSGE_SOL(:,NeedResolved) = GDSGE_X0Rand(:,NeedResolved);
        GDSGE_SKIP(~NeedResolved) = 1;
        
        [GDSGE_SOL,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL,GDSGE_OPT_INFO] = mex_rbc(GDSGE_SOL,GDSGE_LB,GDSGE_UB,GDSGE_DATA,GDSGE_SKIP,GDSGE_F,GDSGE_AUX,GDSGE_EQVAL);
    
        if UseAdaptiveBoundInSol==1
            % Tentatively adjust the bound
            GDSGE_LB_OLD = GDSGE_LB;
            GDSGE_UB_OLD = GDSGE_UB;
            
            
            
            % Hitting lower bound
            GDSGE_SOL_hitting_lower_bound = abs(GDSGE_SOL - GDSGE_LB_OLD) < 1e-8;
            GDSGE_SOL_hitting_upper_bound = abs(GDSGE_SOL - GDSGE_UB_OLD) < 1e-8;
            
            % Adjust for those hitting lower bound or upper bound
            GDSGE_LB(~GDSGE_SOL_hitting_lower_bound) = GDSGE_LB_OLD(~GDSGE_SOL_hitting_lower_bound);
            GDSGE_UB(~GDSGE_SOL_hitting_upper_bound) = GDSGE_UB_OLD(~GDSGE_SOL_hitting_upper_bound);
        end
    end
    
    c=GDSGE_SOL(1:1,:);
K_next=GDSGE_SOL(2:2,:);

    
    w=GDSGE_AUX(1,:);

    
    GDSGE_SHOCK_VAR_LINEAR_INDEX = SimuRslt.shock(:,GDSGE_t+1) + GDSGE_SHOCK_VAR_INDEX_BASE;
    SimuRslt.c(:,GDSGE_t)=c;
SimuRslt.K(:,GDSGE_t)=K;
SimuRslt.w(:,GDSGE_t)=w;
SimuRslt.K(:,GDSGE_t+1) = K_next(:);



    
    
    
    if mod(GDSGE_t,SimuPrintFreq)==0
        fprintf('Periods: %d\n', GDSGE_t);
        SimuRsltNames = fieldnames(SimuRslt);
        for GDSGE_field = 1:length(SimuRsltNames)
            fprintf('%8s', SimuRsltNames{GDSGE_field});
        end
        fprintf('\n');
        for GDSGE_field = 1:length(SimuRsltNames)
            fprintf('%8.4g', SimuRslt.(SimuRsltNames{GDSGE_field})(1,GDSGE_t));
        end
        fprintf('\n');
        toc;
        tic;
    end
    
    if mod(GDSGE_t,SimuSaveFreq)==0
        save(['SimuRslt_rbc_' num2str(GDSGE_t) '.mat'], 'SimuRslt');
    end
end
end